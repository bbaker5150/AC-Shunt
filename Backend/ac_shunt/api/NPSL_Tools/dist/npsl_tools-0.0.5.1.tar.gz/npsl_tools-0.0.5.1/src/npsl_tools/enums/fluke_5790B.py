from enum import Enum

class CALIBRATION_STEPS_5790B(int, Enum):
    ASFOUND = 1
    ADJUST = 2
    ASLEFT = 3

class CALIBRATION_STATUS_5790B(int, Enum):
    INIT = 0
    ASFOUND = 1
    ADJUST = 2
    ASLEFT = 3
    DONE = 4

class STANDARD_LABELS_5790B(int, Enum):
    SOURCE = 1
    DMM = 2

class MESSAGE_TYPE_5790B(int, Enum):
    (
        ERROR,
        ACK,
        LOG,

        CREATE_NEW_CAL,
        RESUME_OLD_CAL,
        GET_CAL_DETAILS,
        
        SAVE_INSTRUMENTS,
        SCAN_INSTRUMENTS,
        ZERO_INSTRUMENTS,
        GET_TEST_POINTS,

        START_CALIBRATION,
        PAUSE_CALIBRATION,
        SELECT_TEST_POINTS,
        SAVE_SETTINGS,
        SAVE_CORRECTIONS,
        SAVE_CORRECTIONS_AC,

        MEASUREMENT_DATA,
        TEST_POINT_DATA,
        TEST_POINT_COMPLETE,
        STEP_COMPLETE,
     ) = range(20)