from enum import Enum
import os
import json
def convert_function_value(data):
    class TEST_POINT_TYPE_5790B(int, Enum):
        DC = 0
        AC = 1
        FLAT = 2
        GAIN = 3
        LIN = 4
        SERVICE = 5
    if 'function' in data:
        data['function'] = TEST_POINT_TYPE_5790B(data['function'])
    return data
def retrieve_nist_point_list():
    # Define the Enum class for function types
    # Define the relative path to the JSON file
    relative_path = os.path.join('myenv', 'Lib', 'site-packages', 'npsl_tools', 'enums', '5790B_NIST_WB.json')

    # Open the JSON file and load its content into a variable
    with open(relative_path, 'r') as file:
        json_content = json.load(file)
    NIST_WB_POINTS = [convert_function_value(item) for item in json_content]
    for item in NIST_WB_POINTS:
        item.update({"NistPoint": True})

    return NIST_WB_POINTS
def to_dict(obj: Enum):
    ret = {}
    for m in list(obj):
        ret.setdefault(m.name, m.value)
    return ret

def to_reverse_dict(obj: Enum):
    ret = {}
    for m in list(obj):
        ret.setdefault(m.value, m.name)
    return ret
