from enum import Enum

def to_dict(obj: Enum):
    ret = {}
    for m in list(obj):
        ret.setdefault(m.name, m.value)
    return ret

def to_reverse_dict(obj: Enum):
    ret = {}
    for m in list(obj):
        ret.setdefault(m.value, m.name)
    return ret