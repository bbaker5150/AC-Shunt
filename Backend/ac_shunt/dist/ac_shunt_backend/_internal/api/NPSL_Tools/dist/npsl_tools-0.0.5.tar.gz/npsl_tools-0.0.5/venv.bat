.venv/scripts/activate.bat 
