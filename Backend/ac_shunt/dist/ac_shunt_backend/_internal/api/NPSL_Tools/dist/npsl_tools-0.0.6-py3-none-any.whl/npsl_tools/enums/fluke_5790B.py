from enum import Enum

class CALIBRATION_STEPS_5790B(int, Enum):
    ASFOUND = 1
    ADJUST = 2
    ASLEFT = 3

class CALIBRATION_STATUS_5790B(int, Enum):
    INIT = 0
    ASFOUND = 1
    ADJUST = 2
    ASLEFT = 3
    DONE = 4

class STANDARD_LABELS_5790B(int, Enum):
    SOURCE = 1
    DMM = 2
    WVS = 3
    FC = 4
    AMP = 5
    TS = 6
    RS = 7
    EM = 8

class SERIAL_NUMBERS_5790B():
    SOURCE = ["5012503", "5444504"]
    DMM = [""]
    WVS = ["1733304"]
    FC = ["3710A04214"]
    AMP = ["6555011"]
    TS = ["5789002"]
    RS = ["8112002"]
    EM = ["A4C343"]


class MESSAGE_TYPE_5790B(int, Enum):
    (
        ERROR,
        ACK,
        LOG,

        CREATE_NEW_CAL,
        RESUME_OLD_CAL,
        GET_CAL_DETAILS,
        
        SAVE_INSTRUMENTS,
        SCAN_INSTRUMENTS,
        ZERO_INSTRUMENTS,
        GET_TEST_POINTS,

        START_CALIBRATION,
        PAUSE_CALIBRATION,
        SELECT_TEST_POINTS,
        SAVE_SETTINGS,
        SAVE_CORRECTIONS_DC,
        SAVE_CORRECTIONS_AC,
        SAVE_CORRECTIONS_WB,

        MEASUREMENT_DATA,
        TEST_POINT_DATA,
        TEST_POINT_COMPLETE,
        STEP_COMPLETE,
     ) = range(21)